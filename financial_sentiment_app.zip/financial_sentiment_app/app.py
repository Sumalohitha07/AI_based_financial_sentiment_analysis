import streamlit as st
import joblib
import re

# Load model and vectorizer from local directory
model = joblib.load("sentiment_model.pkl")
vectorizer = joblib.load("tfidf_vectorizer.pkl")

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# Streamlit UI
st.title("🧠 Financial Sentiment Predictor")

user_input = st.text_area("Enter financial news or stock headline:")

if st.button("Predict Sentiment"):
    cleaned = clean_text(user_input)
    features = vectorizer.transform([cleaned])
    prediction = model.predict(features)[0]

    label_map = {0: "Bearish 📉", 1: "Bullish 📈", 2: "Neutral 😐"}
    st.success(f"Predicted Sentiment: **{label_map[prediction]}**")
